import type { ComponentType } from 'react'

export type SlotName =
  | 'event-editor.dock'
  | 'event-editor.fix-it-panel'
  | 'event-editor.fix-it-route'
  | 'chat.panel.global'
  | 'chat.panel.literature'
  | 'chat.panel.materials'
  | 'chat.panel.formulations'
  | 'chat.panel.ingestion'
  | 'chat.panel.protocol-ide'
  | 'chat.panel.run-workspace'
  | 'ingestion.ai-suggestion'
  | 'ingestion.ai-analysis'
  | 'run-workspace.claim-draft'
  | 'settings.ai-section'

export type SlotComponentMap = Partial<Record<SlotName, ComponentType<any>>>
