# @cla-lab/ai-extension-api

Public extension API for [`computable-lab`](https://github.com/brad-usredoxlabs/computable-lab). Defines the named UI slots and the `AiClient` contract that overlays implement to add AI features to the host.

This package contains **types only** — interface declarations, no implementations. Both the AGPL3 host and proprietary overlays depend on it.

## Concepts

- **Slot**: a named mount point in the host UI (e.g. `event-editor.dock`) where an overlay can render a React component. Slots without a registered renderer fall back to a no-op stub in the host.
- **AiClient**: the backend contract an overlay's AI gateway must implement. Methods cover streaming chat, draft compilation, thread persistence, and fix-it loops.
- **ExtensionManifest**: what an overlay package exports as `manifest` — a slot registry plus an `AiClient` factory plus optional MCP tool plugins.

See `computable-lab/docs/overlays.md` for a complete authoring guide.

## Versioning

Stable v1 covers all currently-shipped slot names and `AiClient` methods. Breaking changes bump the major.
