export interface AiHealthStatus {
  available: boolean
  error?: string
  model?: string
  provider?: string
}

export interface AiClient {
  getHealth(): Promise<AiHealthStatus>
}

export class NullAiClient implements AiClient {
  async getHealth(): Promise<AiHealthStatus> {
    return { available: false, error: 'AI overlay not installed' }
  }
}
