import type { AiClient } from './AiClient.js'
import type { SlotComponentMap } from './slots.js'

export interface ExtensionManifest {
  slots: SlotComponentMap
  aiClient?: AiClient | null
}

export const NULL_MANIFEST: ExtensionManifest = {
  slots: {},
  aiClient: null,
}
